import "../components/hero-detail";
import { restaurantApiService } from "../services/restaurant/api";
import { UrlParser } from "../libs/url-parser";
import { LikeButtonInitiator } from "../libs/like";
import { DetailCardComponent } from "../components/detail-card";
import { restaurantIdbService } from "../services/restaurant/idb";

const detailData = (item) => `
        <h1 class="hero__heading">${item.name}</h1>
        <p class="hero__subheading">${item.categories
          .map((x) => x.name)
          .join(", ")}</p>
        <div style="display: flex; gap: 10px; justifyContent: space-between">
           <button id="like__btn" class="cta__button__primary"><i class="fa fa-heart"></i> Add To Favorite</button>
        </div>
`;

export const DetailPage = {
  async render() {
    return `
            <herodetail-component>
            </herodetail-component>
            <div id="detail-card"></div>
           `;
  },

  async afterRender() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const detail = await restaurantApiService.getRestaurantDetail(url.id);
    const detailElement = document.getElementById("detail-data");
    const detailCard = document.getElementById("detail-card");
    detailCard.style.marginTop = "20px";
    detailCard.style.marginBottom = "20px";
    detailElement.innerHTML = detailData(detail.restaurant);
    detailCard.innerHTML = DetailCardComponent(detail.restaurant);
    LikeButtonInitiator.init({
      favoriteButtonContainer: document.querySelector("#like__btn"),
      favoriteRestaurants: restaurantIdbService,
      restaurant: {
        id: detail.restaurant.id,
        name: detail.restaurant.name,
        city: detail.restaurant.city,
        description: detail.restaurant.description,
        pictureId: detail.restaurant.pictureId,
        rating: detail.restaurant.rating,
      },
    });
  },
};
