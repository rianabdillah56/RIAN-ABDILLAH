import "../components/hero-favorite";
import { restaurantIdbService } from "../services/restaurant/idb";
import { FavoriteCardComponent } from "../components/favorite-card";

const restaurantList = (items) =>
  items.map((item) => FavoriteCardComponent(item)).join("");

export const FavoriteListPage = {
  async render() {
    return `
          <favoritehero-component>
          </favoritehero-component>
          <div class="card__wrapper"></div>
    `;
  },
  async afterRender() {
    const data = await restaurantIdbService.getRestaurantList();
    const list = document.querySelector(".card__wrapper");
    list.innerHTML = restaurantList(data);
  },
};
