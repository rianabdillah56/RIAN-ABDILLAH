import "../components/hero";
import { restaurantApiService } from "../services/restaurant/api";
import { CardComponent } from "../components/card";

const restaurantList = (items) =>
  items.map((item) => CardComponent(item)).join("");

export const ListPage = {
  async render() {
    return `
          <hero-component>
          </hero-component>
          <div class="card__wrapper"></div>
    `;
  },
  async afterRender() {
    const data = await restaurantApiService.getRestaurantList();
    const list = document.querySelector(".card__wrapper");
    list.innerHTML = restaurantList(data.restaurants);
  },
};
