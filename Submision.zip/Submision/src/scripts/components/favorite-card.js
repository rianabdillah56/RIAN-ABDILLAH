import { restaurantApiService } from "../services/restaurant/api";
import { restaurantIdbService } from "../services/restaurant/idb";

export const FavoriteCardComponent = (item) => {
  const deleteRestaurant = async (id) => {
    await restaurantIdbService.deleteRestaurant(id);
  };

  const cardContainer = document.createElement("div");
  cardContainer.className = "card__container";

  cardContainer.innerHTML = `
      <img class="card__image" src="${restaurantApiService.getRestaurantImage({
        id: item.pictureId,
        size: "large",
      })}" alt="${item.name || "Restaurant Image"}" />
      <div class="card__content">
        <div class="card__details">
          <h1 class="card__heading">${item.name || "Restaurant Name"}</h1>
          <p style="font-size: 14px; line-height: 1.5">
            ${
              item.description?.substring(0, 100) || "No description available."
            }
          </p>
          <span>Rating: ${item.rating || "N/A"}</span>
          <span>Location: ${item.city || "N/A"}</span>
        </div>
        <div>
          <a style="all: unset; cursor: pointer; margin-right: 10px" href="#/detail/${
            item.id
          }">
            <button class="cta__button__secondary">Detail Restaurant</button>
          </a>
          
        </div>
      </div>
  `;

  
  return cardContainer.outerHTML;
};
