import { restaurantApiService } from "../services/restaurant/api";

export const DetailCardComponent = (item) => `
            <div class="card__container">
              <img width="400" style="border-radius: 10px" src="${restaurantApiService.getRestaurantImage(
                {
                  id: item.pictureId,
                  size: "large",
                }
              )}" alt="${item.name || "Restaurant Image"}" />
              <div class= "card__content" >
                <div class="card__details">
                  <h1 class="card__heading">${
                    item.name || "Restaurant Name"
                  }</h1>
                  <p style="font-size: 14px; line-height: 1.5">${
                    item.description || "No description available."
                  }</p>
                
                  <span style="margin-top: 20px; font-weight: 600">Rating: 
                    ${Array.from({ length: item.rating })
                      .map(
                        () =>
                          '<i style="color: #f7b602" class="fa fa-star" /></i>'
                      )
                      .join("")}
                    <span style="font-weight: 400"> ${
                      item.rating || "N/A"
                    }</span>
                  </span>
                  <span style="font-weight: 600">
                    Location: 
                    <span style="font-weight: 400"> ${item.city || "N/A"}
                    </span>
                  </span>

                  <span style="font-weight: 600; margin-top: 20px; margin-bottom: 20px;">
                    Food Menu: 
                    <ul style="font-weight: 400; display: flex; flex-direction: column; gap: 10px; margin-top: 20px;">
                      ${item.menus.foods
                        .map((x) => `<li>- ${x.name}</li>`)
                        .join("")}
                    </ul>
                  </span>

                  <span style="font-weight: 600; margin-top: 20px; margin-bottom: 20px;">
                    Drink Menu: 
                    <ul style="font-weight: 400; display: flex; flex-direction: column; gap: 10px; margin-top: 20px;">
                      ${item.menus.drinks
                        .map((x) => `<li>- ${x.name}</li>`)
                        .join("")}
                    </ul>
                  </span>

                  <span style="font-weight: 600; margin-top: 20px; margin-bottom: 20px;">
                    Customer Reviews
                    <ul style="font-weight: 400; display: flex; flex-direction: column; gap: 10px; margin-top: 20px;">
                      ${item.customerReviews
                        .map(
                          (x) => ` <li>
                                      <span style="font-weight: 600">${x.name} : </span>
                                      <span>${x.review}</span>
                                    </li>
                                  `
                        )
                        .join("")}
                    </ul>
                  </span>


                </div>
              </div>
            </div>
  `;
