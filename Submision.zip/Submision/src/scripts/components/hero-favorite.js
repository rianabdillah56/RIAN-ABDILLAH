class FavoriteHeroComponent extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
     <section class="hero__wrapper">
      <div class="hero__favorite__bg__image"></div>
      <div class="hero__container">
        <h1 class="hero__heading">Favorite Restaurant</h1>
      </div>
     </section>
    `;
  }
}

customElements.define("favoritehero-component", FavoriteHeroComponent);
