class HeroComponent extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
     <section class="hero__wrapper">
      <div class="hero__bg__image"></div>
      <div class="hero__container">
        <h1 class="hero__heading">Welcome to Restaurant Finder</h1>
        <h2 class="hero__subheading">Discover your next favorite place</h2>
        <div style="display: flex; gap: 10px; justifyContent: space-between">
          <button class="cta__button__secondary">Learn More</button>
          <a href="/#/favorite" style="all: unset" >
            <button class="cta__button__primary">Favorite Restaurant</button>
          </a>
        </div>
      </div>
     </section>
    `;
  }
}

customElements.define("hero-component", HeroComponent);
