// like-button.js

export const likeButton = () => `
  
  <button id="like__btn" aria-label="like this restaurant">Add to Favorite</button>
`;

export const likedButton = () => `
  
  <button id="like__btn" aria-label="unlike this restaurant">Remove from Favorite</button>
`;
