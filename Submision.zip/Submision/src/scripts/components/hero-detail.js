class HeroDetailComponent extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
     <section class="hero__wrapper">
      <div class="hero__detail__bg__image"></div>
      <div id="detail-data" class="hero__container">
      </div>
     </section>
    `;
  }
}

customElements.define("herodetail-component", HeroDetailComponent);
