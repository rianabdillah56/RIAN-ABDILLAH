class FooterComponent extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
      <footer class="footer__container">
        <div class="footer__content">
          <p>&copy; 2024 Resto Finder</p>
        </div>
      </footer>
    `;
  }
}

customElements.define("footer-component", FooterComponent);
