class NavbarComponent extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
    <navbar id="navbar" class="navbar">
      <span class="logo">Restaurant Finder</span>
       <ul class="navbar__lists">
         <li class="navbar__list">
           <a class="navbar__link" href="https://www.facebook.com/rian.abdillah.1840">About</a>
         </li>
         <li class="navbar__list">
           <a class="navbar__link" href="#list">List</a>
         </li>
         <li class="navbar__list">
           <a class="navbar__link" href="#/favorite">Favorite</a>
         </li>
       </ul>
      <button class="cta__button">Find a Restaurant</button>
      <button class="hamburger" id="hamburger">
        <span class="hamburger__line"></span>
        <span class="hamburger__line"></span>
        <span class="hamburger__line"></span>
      </button>
      <div class="navbar__mobile">
         <a class="navbar__link" href="https://www.facebook.com/rian.abdillah.1840">About</a>
         <a class="navbar__link" href="#list">List</a>
         <a class="navbar__link" href="#/favorite">Favorite</a>
      </div>
    </navbar>
    
    `;
  }
}

customElements.define("navbar-component", NavbarComponent);
