export const config = {
  BASE_URL: "https://restaurant-api.dicoding.dev",
  DEFAULT_LANGUAGE: "en-us",
  CACHE_NAME: new Date().toISOString(),
  DATABASE_NAME: "restaurants-db",
  DATABASE_VERSION: 1,
  OBJECT_STORE_NAME: "restaurants-store",
};
