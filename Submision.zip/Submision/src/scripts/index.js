import "regenerator-runtime";
import "lazysizes";
import "lazysizes/plugins/parent-fit/ls.parent-fit";
import "./components/navbar";
import "./components/footer";
import "../styles/index.css";
import { swRegister } from "./libs/sw-register";
import App from "./pages/app";

const app = new App({
  button: document.querySelector("#hamburger"),
  drawer: document.querySelector("#navbar"),
  content: document.querySelector("#app"),
});

window.addEventListener("hashchange", () => {
  app.renderPage();
});

window.addEventListener("load", async () => {
  app.renderPage();
  await swRegister();
});
