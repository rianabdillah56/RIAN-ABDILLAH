import { indexedDB } from "../../libs/idb";
import { config } from "../../config";

const { OBJECT_STORE_NAME } = config;

export const restaurantIdbService = {
  async getRestaurantList() {
    const db = await indexedDB;
    return db.getAll(OBJECT_STORE_NAME);
  },

  async setRestaurantList(restaurants) {
    const db = await indexedDB;
    return db.set(OBJECT_STORE_NAME, restaurants);
  },

  async getRestaurantSearchList(query) {
    const getRestaurantList = await this.getRestaurantList();
    return getRestaurantList.filter((restaurant) => {
      const loweredCaseRestaurantTitle = (restaurant.name || "-").toLowerCase();
      const filteredRestaurantTitle = loweredCaseRestaurantTitle.replace(
        /\s/g,
        "",
      );
      const loweredCaseQuery = query.toLowerCase();
      const filteredQuery = loweredCaseQuery.replace(/\s/g, "");
      return filteredRestaurantTitle.indexOf(filteredQuery) !== -1;
    });
  },

  async getRestaurantDetail(id) {
    if (!id) {
      return;
    }
    const db = await indexedDB;
    return db.get(OBJECT_STORE_NAME, id);
  },

  async updateRestaurant(restaurant) {
    if (!restaurant || !restaurant.id) {
      throw new Error("The restaurant object must have a valid 'id' property.");
    }

    const db = await indexedDB;
    return db.put(OBJECT_STORE_NAME, restaurant);
  },

  async deleteRestaurant(id) {
    const db = await indexedDB;
    return db.delete(OBJECT_STORE_NAME, id);
  },
};
