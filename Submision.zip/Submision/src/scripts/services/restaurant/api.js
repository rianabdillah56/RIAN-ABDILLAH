import { fetchApi } from "../../libs/fetch";
import { config } from "../../config";

export const restaurantApiService = {
  getRestaurantList: async () => {
    const response = await fetchApi({
      url: "/list",
      request: {
        method: "GET",
      },
    });
    return response;
  },

  getRestaurantSearchList: async (search) => {
    const response = await fetchApi({
      params: {
        search,
      },
      url: "/search",
      request: {
        method: "GET",
      },
    });
    return response;
  },

  getRestaurantDetail: async (id) => {
    const response = await fetchApi({
      url: `/detail/${id}`,
      request: {
        method: "GET",
      },
    });
    return response;
  },

  getRestaurantImage: (payload) =>
    `${config.BASE_URL}/images/${payload.size}/${payload.id}`,

  createRestaurantReview: async (payload) => {
    const response = await fetchApi({
      url: "/review",
      request: {
        method: "POST",
        body: payload,
      },
    });
    return response;
  },
};
